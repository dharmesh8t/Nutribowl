import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const base=path.resolve('dist');
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webp':'image/webp','.png':'image/png','.woff2':'font/woff2','.svg':'image/svg+xml'};
http.createServer((req,res)=>{let file;try{file=path.resolve(base,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname))}catch{res.writeHead(400).end();return}if(!file.startsWith(base+path.sep)&&file!==base){res.writeHead(403).end();return}if(!fs.existsSync(file)||fs.statSync(file).isDirectory()){if(path.extname(file)){res.writeHead(404).end('Not found');return}file=path.join(base,'index.html')}res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});fs.createReadStream(file).pipe(res)}).listen(5175,'127.0.0.1',()=>console.log('Local: http://127.0.0.1:5175/'));
