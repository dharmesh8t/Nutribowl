Place meal photos in this folder. See IMAGE-GUIDE.md in the project root for exact file names.
