# Add your meal photos

Put your own WebP images in `public/assets/meals/`. Use landscape images around 1000 × 600 pixels, ideally under 250 KB. The website crops them neatly to fit. No changes to the component are needed when these names are used.

Missing images show the designed “Photo coming soon” space. You can add images gradually. Save as actual WebP files; simply renaming a JPEG is not a conversion.

| Meal | File name |
| --- | --- |
| Monday breakfast — Fruit, yogurt & granola | `monday-breakfast-veg.webp` |
| Monday lunch — Coconut milk pulao & roasted paneer | `monday-lunch-veg.webp` |
| Monday lunch — Coconut milk pulao & roasted chicken | `monday-lunch-mixed.webp` |
| Monday dinner — Paneer & hummus vegetable wrap | `monday-dinner-veg.webp` |
| Monday dinner — Egg & hummus vegetable wrap | `monday-dinner-mixed.webp` |
| Tuesday breakfast — Puttu & kadala curry | `tuesday-breakfast-veg.webp` |
| Tuesday lunch — Mashed potato & paneer plate | `tuesday-lunch-veg.webp` |
| Tuesday lunch — Mashed potato & chicken plate | `tuesday-lunch-mixed.webp` |
| Tuesday dinner — Aloo paratha & paneer gravy | `tuesday-dinner-veg.webp` |
| Tuesday dinner — Aloo paratha & chicken gravy | `tuesday-dinner-mixed.webp` |
| Wednesday breakfast — Pancakes, honey & fruit | `wednesday-breakfast-veg.webp` |
| Wednesday lunch — Mint rice, paneer tikka & rajma | `wednesday-lunch-veg.webp` |
| Wednesday lunch — Mint rice, chicken tikka & rajma | `wednesday-lunch-mixed.webp` |
| Wednesday dinner — Chapati, chana & raita | `wednesday-dinner-veg.webp` |
| Thursday breakfast — Multigrain bread & spinach-paneer roll | `thursday-breakfast-veg.webp` |
| Thursday breakfast — Multigrain bread & spinach-egg roll | `thursday-breakfast-mixed.webp` |
| Thursday lunch — Brown rice, rajma & paneer | `thursday-lunch-veg.webp` |
| Thursday lunch — Brown rice, rajma & egg | `thursday-lunch-mixed.webp` |
| Thursday dinner — Paneer & vegetable pasta | `thursday-dinner-veg.webp` |
| Thursday dinner — Chicken & vegetable pasta | `thursday-dinner-mixed.webp` |
| Friday breakfast — Mini idlis, chutney & paneer tikka | `friday-breakfast-veg.webp` |
| Friday lunch — Millet rice & paneer tikka | `friday-lunch-veg.webp` |
| Friday lunch — Millet rice & chicken tikka | `friday-lunch-mixed.webp` |
| Friday dinner — Chapati & palak paneer | `friday-dinner-veg.webp` |

Shared dishes use the vegetarian image for both preferences. Mixed alternatives have their own image so paneer and chicken are not confused.

After adding images run `npm run build` and redeploy to Vercel. Refresh the local page to see them. If you prefer JPG/PNG, update the `.webp` extension in `MealPhoto` inside `src/sections/WeeklyMeals.tsx` consistently.
