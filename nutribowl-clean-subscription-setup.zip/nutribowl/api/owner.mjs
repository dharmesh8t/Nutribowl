import {reply,readBody,InputError} from '../server/payments.mjs';
import {ownerReady,validPassword,session,authorized,cookie} from '../server/owner-auth.mjs';
import {store,storageReady} from '../server/order-store.mjs';
import {uuid,reconcile} from '../server/meal-orders.mjs';
import {alertOwner,emailReady} from '../server/alerts.mjs';
export default async function handler(req,res){
 if(req.method==='GET')return reply(res,200,{configured:ownerReady()&&storageReady(),authenticated:authorized(req),emailAlerts:emailReady()});
 if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
 if(!process.env.PUBLIC_SITE_URL||req.headers.origin!==new URL(process.env.PUBLIC_SITE_URL).origin)return reply(res,403,{error:'Request not allowed'});
 if(!ownerReady()||!storageReady())return reply(res,503,{error:'Owner access and order storage have not been connected yet.'});
 try{
 const input=await readBody(req);
 if(input.action==='login'){if(!validPassword(input.password))return reply(res,401,{error:'Incorrect owner password.'});res.setHeader('Set-Cookie',cookie(session()));return reply(res,200,{authenticated:true});}
 if(!authorized(req))return reply(res,401,{error:'Please sign in again.'});
 if(input.action==='logout'){res.setHeader('Set-Cookie',cookie(''));return reply(res,200,{ok:true});}
 if(input.action==='list'){const offset=Number.isInteger(input.offset)&&input.offset>=0?Math.min(input.offset,100000):0;return reply(res,200,{orders:await store.list(offset)});}
 if(!uuid(input.id))throw new InputError('Invalid order reference.');
 let row=await store.get(input.id);if(!row)throw new InputError('Order not found.');
 if(input.action==='check'||input.action==='confirm')row=await reconcile(row);
 if(input.action==='confirm'){
 if(row.is_test)throw new InputError('Test orders cannot be confirmed for delivery.');
 if(row.status!=='paid'||row.payment_state!=='captured')throw new InputError('Only verified, paid orders can be confirmed.');
 row=await store.update(row.id,{status:'confirmed',confirmed_at:new Date().toISOString()},'&status=eq.paid&is_test=eq.false');
 if(!row)throw new InputError('This order changed. Refresh your orders.');
 await alertOwner(row,'confirmed');
 }else if(input.action==='retryAlert'){const event=row.status==='awaiting_payment'?'new':row.status;if(!await alertOwner(row,event))throw new InputError('Email could not be sent. Check your email configuration.');await store.update(row.id,{alert_error:false});}
 else if(input.action!=='check')throw new InputError('Invalid action.');
 return reply(res,200,{ok:true});
 }catch(e){return reply(res,e instanceof InputError?400:503,{error:e instanceof InputError?e.message:'Unable to load or update orders. Please try again.'});}
}
