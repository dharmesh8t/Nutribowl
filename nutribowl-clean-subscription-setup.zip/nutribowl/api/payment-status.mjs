import {endpoint,status} from '../server/payments.mjs';
export default endpoint(status);
