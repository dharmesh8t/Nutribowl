import {ready,reply} from '../server/payments.mjs';
export default function handler(req,res){if(req.method!=='GET')return reply(res,405,{error:'Method not allowed'});reply(res,200,{enabled:false,testMode:(process.env.RAZORPAY_KEY_ID||'').startsWith('rzp_test_')});}
