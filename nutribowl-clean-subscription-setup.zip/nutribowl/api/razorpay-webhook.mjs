import {store,storageReady} from '../server/order-store.mjs';
import {reconcile} from '../server/meal-orders.mjs';
import {validSignature,reply,razorpay} from '../server/payments.mjs';
export const config={api:{bodyParser:false}};
export default async function handler(req,res){
 if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
 if(!process.env.RAZORPAY_WEBHOOK_SECRET)return reply(res,503,{error:'Webhook not configured'});
 try{
 const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>100000)return reply(res,413,{error:'Request too large'});chunks.push(Buffer.from(chunk));}
 const raw=Buffer.concat(chunks);
 if(!validSignature(raw,req.headers['x-razorpay-signature'],process.env.RAZORPAY_WEBHOOK_SECRET))return reply(res,400,{error:'Invalid signature'});
 const event=JSON.parse(raw.toString());
 if(event.event==='payment.captured'||event.event==='order.paid'){
 const payment=event.payload?.payment?.entity;
 if(!payment || !/^order_[A-Za-z0-9]+$/.test(payment.order_id))return reply(res,400,{error:'Missing payment order'});
 const order=await razorpay('orders/'+payment.order_id);
 if(order.notes?.business!=='Nutribowl')return reply(res,200,{received:true});
 if(order.status!=='paid'||payment.status!=='captured'||order.amount!==payment.amount||order.currency!=='INR'||payment.currency!=='INR')return reply(res,409,{error:'Payment not reconciled'});
 if(order.notes?.meal_order_id){if(!storageReady())return reply(res,503,{error:'Order storage unavailable'});const row=await store.find('razorpay_order_id',payment.order_id);if(!row)return reply(res,503,{error:'Order not linked yet'});await reconcile(row);}
 // Razorpay's order + captured payment are the durable source of truth.
 // No delivery is dispatched here. Repeated webhook deliveries have no side effects.
 }
 if(event.event==='refund.processed'&&storageReady()){const paymentId=event.payload?.refund?.entity?.payment_id;if(paymentId){const row=await store.find('payment_id',paymentId);if(row)await reconcile(row);}}
 return reply(res,200,{received:true});
 }catch{return reply(res,503,{error:'Please retry delivery'});}
}
