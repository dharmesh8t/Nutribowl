// The former six-day product checkout is retired from the five-day website.
import {reply} from '../server/payments.mjs';
export default function handler(req,res){return reply(res,410,{error:'Please use the Monday–Friday meal subscription form.'});}
