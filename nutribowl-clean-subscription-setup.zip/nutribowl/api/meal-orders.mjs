import {config,submit,startPayment,check,uuid} from '../server/meal-orders.mjs';
import {reply,readBody,InputError} from '../server/payments.mjs';
export default async function handler(req,res){
 if(req.method==='GET')return reply(res,200,config());
 if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
 if(!process.env.PUBLIC_SITE_URL||req.headers.origin!==new URL(process.env.PUBLIC_SITE_URL).origin)return reply(res,403,{error:'Request not allowed'});
 try{const input=await readBody(req);if(!uuid(input.id))throw new InputError('Invalid order reference.');const action={submit,startPayment,check}[input.action];if(!action)throw new InputError('Invalid action.');reply(res,200,await action(input));}catch(e){reply(res,e instanceof InputError?400:503,{error:e instanceof InputError?e.message:'Order service is temporarily unavailable. Retry with the same reference; do not make another payment.'});}
}
