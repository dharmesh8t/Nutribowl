# Nutribowl — 21–25 September 2026

Five-day meal list. Prices: ₹180 per meal for each portion size (initial assumption). ₹900 for one meal daily for five days; ₹540/day or ₹2,700/week for all three meals. Delivery extra / confirmed separately.

| Day | Breakfast | Lunch | Dinner |
|---|---|---|---|
| Monday | Fruit, yogurt & granola | Coconut milk pulao & roasted paneer / Coconut milk pulao & roasted chicken | Paneer & hummus vegetable wrap / Egg & hummus vegetable wrap |
| Tuesday | Puttu & kadala curry | Mashed potato & paneer plate / Mashed potato & chicken plate | Aloo paratha & paneer gravy / Aloo paratha & chicken gravy |
| Wednesday | Pancakes, honey & fruit | Mint rice, paneer tikka & rajma / Mint rice, chicken tikka & rajma | Chapati, chana & raita |
| Thursday | Multigrain bread & spinach-paneer roll / Multigrain bread & spinach-egg roll | Brown rice, rajma & paneer / Brown rice, rajma & egg | Paneer & vegetable pasta / Chicken & vegetable pasta |
| Friday | Mini idlis, chutney & paneer tikka | Millet rice & paneer tikka / Millet rice & chicken tikka | Chapati & palak paneer |

## Portion and nutrition comparison

**Illustrative recipe estimates, not verified nutrition.** Values come from proposed ingredient weights and preparation profiles. 500 ml = Light, 750 ml = Regular, 1,000 ml = Hearty. Each entry below is kcal / protein g / carbohydrate g. Box capacity is not food weight.

### Vegetarian (no eggs)

| Day / meal | Menu | 500 ml | 750 ml | 1,000 ml |
|---|---|---|---|---|
| Monday Breakfast | Fruit, yogurt & granola | ~230 / 6 / 35 | ~300 / 9 / 46 | ~390 / 11 / 60 |
| Monday Lunch | Coconut milk pulao & roasted paneer | ~480 / 19 / 46 | ~640 / 25 / 61 | ~830 / 33 / 80 |
| Monday Dinner | Paneer & hummus vegetable wrap | ~410 / 20 / 39 | ~540 / 27 / 52 | ~700 / 35 / 67 |
| Tuesday Breakfast | Puttu & kadala curry | ~410 / 11 / 70 | ~550 / 15 / 93 | ~710 / 20 / 121 |
| Tuesday Lunch | Mashed potato & paneer plate | ~400 / 19 / 33 | ~540 / 25 / 44 | ~700 / 33 / 57 |
| Tuesday Dinner | Aloo paratha & paneer gravy | ~500 / 18 / 50 | ~670 / 24 / 67 | ~870 / 32 / 87 |
| Wednesday Breakfast | Pancakes, honey & fruit | ~330 / 7 / 57 | ~440 / 10 / 77 | ~570 / 13 / 100 |
| Wednesday Lunch | Mint rice, paneer tikka & rajma | ~490 / 22 / 59 | ~650 / 29 / 79 | ~850 / 38 / 103 |
| Wednesday Dinner | Chapati, chana & raita | ~380 / 16 / 62 | ~510 / 21 / 82 | ~660 / 27 / 107 |
| Thursday Breakfast | Multigrain bread & spinach-paneer roll | ~380 / 18 / 46 | ~510 / 24 / 61 | ~670 / 31 / 79 |
| Thursday Lunch | Brown rice, rajma & paneer | ~450 / 20 / 60 | ~610 / 27 / 80 | ~790 / 35 / 103 |
| Thursday Dinner | Paneer & vegetable pasta | ~430 / 21 / 53 | ~570 / 27 / 70 | ~740 / 36 / 91 |
| Friday Breakfast | Mini idlis, chutney & paneer tikka | ~370 / 17 / 42 | ~500 / 22 / 56 | ~640 / 29 / 73 |
| Friday Lunch | Millet rice & paneer tikka | ~380 / 20 / 42 | ~510 / 26 / 56 | ~660 / 34 / 73 |
| Friday Dinner | Chapati & palak paneer | ~450 / 21 / 45 | ~600 / 28 / 60 | ~770 / 36 / 79 |

### Egg and chicken options

| Day / meal | Menu | 500 ml | 750 ml | 1,000 ml |
|---|---|---|---|---|
| Monday Breakfast | Fruit, yogurt & granola | ~230 / 6 / 35 | ~300 / 9 / 46 | ~390 / 11 / 60 |
| Monday Lunch | Coconut milk pulao & roasted chicken | ~420 / 27 / 44 | ~560 / 36 / 58 | ~720 / 47 / 76 |
| Monday Dinner | Egg & hummus vegetable wrap | ~360 / 19 / 38 | ~480 / 26 / 50 | ~630 / 33 / 65 |
| Tuesday Breakfast | Puttu & kadala curry | ~410 / 11 / 70 | ~550 / 15 / 93 | ~710 / 20 / 121 |
| Tuesday Lunch | Mashed potato & chicken plate | ~330 / 28 / 30 | ~450 / 37 / 41 | ~580 / 49 / 53 |
| Tuesday Dinner | Aloo paratha & chicken gravy | ~460 / 26 / 49 | ~620 / 35 / 65 | ~800 / 46 / 85 |
| Wednesday Breakfast | Pancakes, honey & fruit | ~330 / 7 / 57 | ~440 / 10 / 77 | ~570 / 13 / 100 |
| Wednesday Lunch | Mint rice, chicken tikka & rajma | ~450 / 30 / 57 | ~600 / 39 / 76 | ~790 / 51 / 99 |
| Wednesday Dinner | Chapati, chana & raita | ~380 / 16 / 62 | ~510 / 21 / 82 | ~660 / 27 / 107 |
| Thursday Breakfast | Multigrain bread & spinach-egg roll | ~340 / 16 / 45 | ~460 / 21 / 60 | ~600 / 28 / 78 |
| Thursday Lunch | Brown rice, rajma & egg | ~390 / 17 / 59 | ~520 / 23 / 78 | ~680 / 30 / 102 |
| Thursday Dinner | Chicken & vegetable pasta | ~380 / 27 / 51 | ~500 / 36 / 68 | ~660 / 47 / 88 |
| Friday Breakfast | Mini idlis, chutney & paneer tikka | ~370 / 17 / 42 | ~500 / 22 / 56 | ~640 / 29 / 73 |
| Friday Lunch | Millet rice & chicken tikka | ~340 / 28 / 39 | ~450 / 37 / 53 | ~590 / 48 / 68 |
| Friday Dinner | Chapati & palak paneer | ~450 / 21 / 45 | ~600 / 28 / 60 | ~770 / 36 / 79 |

## Kitchen review

Confirm recipe weights, brands, oil, allergens, packaging fit, earliest service dates and lunch/dinner delivery times. This first version interprets the last dinner as Friday, mint rice for “peppermint rice,” and kadala curry for “kallakari.” Detailed assumptions are in MEAL-PLAN-NOTES.md.
