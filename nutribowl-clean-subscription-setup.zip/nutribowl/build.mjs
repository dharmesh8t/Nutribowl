import fs from 'node:fs';
import { build } from 'vite';
import ts from 'typescript';
// In-process TypeScript transform also supports restricted Windows environments.
await build({configFile:false,resolve:{preserveSymlinks:true},esbuild:false,plugins:[{name:'typescript-in-process',enforce:'pre',transform(code,id){code=code.replaceAll('process.env.NODE_ENV',JSON.stringify('production')).replaceAll('process.env?.NODE_ENV',JSON.stringify('production'));if(/\.[jt]sx?$/.test(id)&&!id.includes('node_modules'))return {code:ts.transpileModule(code,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}}).outputText,map:null};return {code,map:null}}}],build:{target:'esnext',minify:false,cssMinify:false,rollupOptions:{output:{manualChunks:{react:['react','react-dom'],motion:['motion/react']}}}}});

fs.mkdirSync('server',{recursive:true});
fs.writeFileSync('server/catalog.mjs',ts.transpileModule(fs.readFileSync('src/data/catalog.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);

fs.writeFileSync('server/mealPlan.mjs',ts.transpileModule(fs.readFileSync('src/data/mealPlan.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
