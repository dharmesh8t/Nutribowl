# Your Nutribowl Orders page

The website now has a clean Monday–Friday meal table, room for meal photos, and a two-step subscription form. Your alert destination is **dharmesh8m@gmail.com**.

## Where customer details go

Once connected, customers choose their meal plan and submit their name, address, email and mobile number. The website saves these details in your private Supabase database. You see them in **Owner access** at the bottom of your website (the URL ends in `/#owner`). Sign in with your owner password.

You do not need to read code or open the database to manage routine orders. The private Orders page shows each customer's contact details, delivery address, meals, portion size, amount, payment reference and status.

Your email alert includes an order reference and a link to that page. Full addresses and phone numbers stay on the private page. Alerts cover new requests, verified payments, your confirmations and recorded refunds. Email alerts are a convenience; check Orders daily even if an email does not arrive. A failed alert has a retry button. The system does not automatically email customers or dispatch meals.

## How to confirm a subscription

1. **Awaiting payment:** the customer submitted the form. This is a request, not a confirmed subscription.
2. **Payment received:** the website verified a matching captured payment with Razorpay. Open the order and check the delivery address, schedule and kitchen availability.
3. Click **Confirm subscription**. The status becomes **Confirmed**. Contact the customer to arrange delivery.
4. Use **Verify payment status** if payment appears delayed. Also find the payment/order ID in your Razorpay dashboard. Never ask someone to pay again before checking an interrupted attempt.

Test orders are clearly labelled and cannot be confirmed for delivery. A recorded refund removes the confirmed status; partial refunds also require manual review. Refunds themselves are handled in Razorpay, not through the Orders page.

“Subscription” means one payment for the listed five days. There is no automatic weekly charge or renewal.

## What is ready now

The interface, server code, database table definition, owner sign-in and email integration are included. The preview currently saves no customer details and takes no payment. It shows this clearly. No cloud database/email account has been connected, no live payment has been tested, and this update has not been published to your Vercel site.

## One-time setup on Vercel

These steps can be completed together with whoever manages your hosting. Enter secrets directly into the service dashboards; do not put them in website code or send them in chat.

1. Create/use your Supabase project and run `database/schema.sql` in its SQL editor. The table blocks public and signed-in browser access; your server holds the service role key. Keep this key server-only.
2. In Vercel project settings, add `SUPABASE_URL` (HTTPS origin, no trailing slash) and `SUPABASE_SERVICE_ROLE_KEY`.
3. Add a unique random `OWNER_PASSWORD` of at least 24 characters and a separate random `OWNER_SESSION_SECRET` of at least 32 characters. Save the password in your password manager. Owner sessions last eight hours. Set an edge rate-limit rule for `/api/owner` and `/api/meal-orders` before accepting public traffic to limit login attempts and spam. Rotate the session secret to invalidate all sessions.
4. Connect Resend, verify a sending domain, and set `RESEND_API_KEY`, `ALERT_FROM_EMAIL` (your verified sender) and `OWNER_EMAIL=dharmesh8m@gmail.com`. Gmail is the recipient, not automatically an approved sending address.
5. Set `PUBLIC_SITE_URL` to your exact HTTPS Vercel/custom domain, without a path. Each preview deployment needs its matching origin. Set `ORDERS_ENABLED=true` only after the database and owner login are working.
6. Agree your delivery pricing. Set `MEAL_DELIVERY_FEE_PER_DAY_PAISE`: `0` means free; `3000` means ₹30 per day. This is one combined daily delivery charge for the selected meals, multiplied by five; it does not charge per individual meal or area. Use only a price you can honour. Blank leaves payment unavailable and saves quote-pending requests. Such requests do not automatically receive a new price later; contact the customer and create a fresh order after pricing is set.
7. Follow PAYMENT-SETUP.md when Razorpay is ready. Keep `MEAL_SERVICE_READY=false` and `CHECKOUT_ENABLED=false` until then. Customers can submit requests while payment is unavailable only if orders are enabled.
8. Deploy the complete project to Vercel, not just the `dist` folder. Build: `npm run build`; output: `dist`; Node 22+. Redeploy whenever environment settings change.

Before opening orders, run a synthetic test with the database and email service connected: check that the record appears after a browser refresh, the owner email arrives, and public visitors cannot access customer records. Then complete Razorpay's test-mode payment, interrupted payment and refund tests. These provider integration checks require your accounts and are still outstanding.

The current menu is **21–25 September 2026**. It stops accepting new bookings on Monday 21 September in Indian time. Update the menu/dates for later weeks. Breakfast/lunch/dinner are currently ₹180 each for all sizes; ₹900 for one meal each weekday or ₹2,700 for all three, plus the agreed delivery charge. Nutrition remains illustrative until kitchen recipes and portions are weighed and confirmed.

## If something needs attention

- Email missing: inspect Orders first, then Resend configuration/logs and the retry-alert button.
- Order missing: ensure storage is enabled and redeployed. The preview deliberately does not save records.
- Payment stuck on `creating`: an uncertain provider response is locked to avoid duplicate orders. Have the developer find the order by its receipt/reference in Razorpay and safely reconnect it after checking its amount, currency and order notes. Do not simply clear the lock and charge again.
- A browser recovery reference lasts in that browser tab's session. Customers who lose it should contact you; you can locate the record on the owner page.
- Confirmed orders are not a delivery dispatch system. Maintain your kitchen/delivery process and monitor refunds in Razorpay.
