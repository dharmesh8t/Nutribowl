# Nutribowl weekday menu — 21–25 September 2026

The new homepage section offers breakfast, lunch, dinner and a full-day combo across five days. Customers can choose vegetarian or egg/chicken variants, select 500 ml / 750 ml / 1,000 ml per-meal boxes, inspect portion details and subscribe for all five weekdays using a delivery-details form followed by a payment screen.

## Pricing assumptions used

- Breakfast ₹180, lunch ₹180, dinner ₹180 per meal. Breakfast uses the upper end of the requested ₹170–180 range.
- All box sizes use the same ₹180 introductory meal price for now. The owner has not specified a surcharge for the larger portions.
- One meal a day for five days: ₹900.
- All three meals: ₹540 per day, ₹2,700 for five days, 15 separate meal boxes.
- Delivery is additional / to be confirmed, not silently included. No combo discount, auto-renewal or quantity surcharge is invented.

Edit `MEAL_PRICES` in `src/data/mealPlan.ts` and the explanatory UI copy together if changing prices. Portion multipliers are in `BOXES`.

## Menu interpretations

- “Sixth day” chapati + palak paneer is placed on Friday to complete the requested five dinners.
- “Peppermint rice” is interpreted as mint rice.
- “Puttu + kallakari” is interpreted as puttu with kadala (black chickpea) curry.
- Monday dinner and Thursday breakfast/lunch have paneer alternatives for the egg-free vegetarian menu.
- Pancakes are modelled as egg-free so the vegetarian menu remains egg-free. Confirm the kitchen recipe.
- The mixed menu uses egg or chicken where requested; shared dishes such as Friday palak paneer remain vegetarian.

## Nutrition is provisional

Ingredient quantities and exact recipes were not provided. Figures are **illustrative planning estimates**, not measured nutritional facts, lab-tested results, or exact values sourced from a nutrition database. The model specifies representative profiles per 100 g of prepared component and explicit assumed gram weights. The website exposes those weights and compares all three sizes.

750 ml is the reference serving; 500 ml uses 75% and 1,000 ml uses 130% of the reference recipe weights. These are proposed serving choices, not a volume-to-weight conversion. Confirm packing fit, actual ingredient brands, oil, recipe yield and weighed portions before using these values as verified menu nutrition. Allergens are indicative and require kitchen confirmation.

Background on nutrient data and ingredient-based methods:
- https://fdc.nal.usda.gov/portal-data/external/dataDictionary
- https://www.nin.res.in/ebooks/IFCT2017.pdf

The prepared-dish profiles in the model are assumptions, not quoted database entries.

## Ordering and deployment

The public website offers only this Monday–Friday plan. Saturday and the former product planner have been removed from the homepage. The old create-order endpoint is retired.

The customer selects meals, diet and portion, supplies name/email/mobile/address, and continues to payment. Without service configuration this is an explicitly labelled preview: no details are saved or sent. When enabled, the backend saves the exact five-day menu and server-calculated quote in Supabase. Only order reference and a random recovery token are kept in browser session storage. Owner alerts go to dharmesh8m@gmail.com once Resend is configured. See OWNER-GUIDE.md.

The week is fixed at 21–25 September 2026, not auto-rotated. Bookings and new payment attempts close at the start of Monday in Indian time. Update PLAN_WEEK, WEEK_MENU, visible date labels, tests and review prices before offering another week. Existing saved orders preserve their original menu.

This is a source update and local preview, not a deployment to the public Vercel website. Database, email delivery and Razorpay need private service settings. No real payment was made or email sent while building this version.
