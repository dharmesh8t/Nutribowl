# Razorpay setup for the five-day meal subscription

Customers choose breakfast, lunch, dinner or all three for Monday–Friday, enter their delivery details, then see the payment step. See OWNER-GUIDE.md for database, owner access and email setup first. The former six-day product checkout is retired.

## Server settings

Add these privately to Vercel environment settings. Never prefix secrets with `VITE_` or commit `.env`.

| Setting | Purpose |
| --- | --- |
| CHECKOUT_ENABLED | Keep `false` until testing; then `true` |
| MEAL_SERVICE_READY | `true` only when delivery times, prices and business policies are ready |
| RAZORPAY_KEY_ID | Test Key ID first (`rzp_test_…`) |
| RAZORPAY_KEY_SECRET | Matching private key secret |
| RAZORPAY_WEBHOOK_SECRET | Separate strong webhook secret |
| PUBLIC_SITE_URL | Exact HTTPS website origin |
| MEAL_DELIVERY_FEE_PER_DAY_PAISE | Confirmed combined daily delivery price in paise, including `0` if free |

Database settings and `ORDERS_ENABLED=true` are required too. In Razorpay test mode configure `https://YOUR-DOMAIN/api/razorpay-webhook` with the matching secret and subscribe to `payment.captured`, `order.paid` and `refund.processed`. Use automatic capture. Keep test and live keys/databases separate; changing keys does not convert existing test orders into live orders.

## Verify before launch

Deploy the complete source project (Vercel build `npm run build`, output `dist`, Node 22+), then:

1. Submit a synthetic request. Confirm it is in the owner Orders page and the alert arrives.
2. Complete a Razorpay test payment. Verify that only a captured matching amount changes the order to “Payment received”. Test orders must remain unavailable for delivery confirmation.
3. Test closing checkout, payment failure, refreshing status and opening the saved order. Verify webhook updates even if the customer closes the page.
4. Verify a test refund changes the order status. Replayed webhooks must not downgrade confirmed orders or create duplicate payments.
5. Check private owner access, public order access protection and email failure handling.

No real or provider test payment was made while building this code because credentials were not supplied. The code tests use simulated provider responses. Account activation, service configuration and end-to-end provider testing remain required.

## Live payments and daily use

Once Razorpay approves your merchant account, use live keys and a live webhook, confirm domain/environment settings, and redeploy. The website uses INR and Indian contact details; domestic-only acceptance must also be configured in your Razorpay merchant account. The earlier onboarding purpose-code support ticket is #20975499; this code does not resolve KYC activation.

The backend stores the original five-day menu and quote in Supabase before payment. It calculates the amount from the server menu and delivery settings, creates one Razorpay order, verifies callback signatures, and checks canonical order/payment details. Captured payment is separate from owner acceptance: review the paid order and click “Confirm subscription” on `/#owner`.

Razorpay holds your payment ledger and payment/order IDs; Supabase holds your customer and meal details. No card details are stored in this application. There is no auto-renewal, automated refund, customer-email receipt integration, or automatic delivery dispatch.

Publish your actual business delivery, cancellation/refund, terms and privacy policies and verify service capacity before enabling real payments. The legal notices in this project explain current functionality but still need your business policy content. Prices are the displayed final meal amounts; no separate tax computation is implemented.

Sources: [Razorpay Standard Checkout](https://razorpay.com/docs/payments/payment-gateway/web-integration/standard/integration-steps/) and [Razorpay webhooks](https://razorpay.com/docs/webhooks/).
