# Deployment status

Original live website recorded in the supplied project: https://nutribowl-fresh.vercel.app/

This payment update has not been deployed to that website. Deploy the complete source (including api/ and server/), not just dist/. See PAYMENT-SETUP.md. Test API keys and business policy review are required before accepting live payments.
