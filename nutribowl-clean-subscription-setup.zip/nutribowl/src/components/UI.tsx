import { useEffect,useRef,ReactNode } from 'react';
import { WA_CATALOG_URL } from '../data/catalog';
export function Arrow({diagonal=false}:{diagonal?:boolean}) {return <svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{diagonal?<path d="M7 17 17 7M7 7h10v10"/>:<path d="M5 12h14m-6-6 6 6-6 6"/>}</svg>}
export function CatalogLink({children='Subscribe on WhatsApp',className='',...props}:{children?:ReactNode;className?:string;'aria-label'?:string}) {return <a className={`button ${className}`} href={WA_CATALOG_URL} {...props}>{children}<Arrow diagonal/></a>}
export function Logo(){return <a className="brand" href="/#home" aria-label="Nutribowl home"><img src="/assets/logo.png" width="66" height="66" alt="Nutribowl"/></a>}
export function Modal({children,onClose,label,className=''}:{children:ReactNode;onClose:()=>void;label:string;className?:string}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const d=ref.current!;const previous=document.activeElement as HTMLElement;d.showModal();const old=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{d.close();document.body.style.overflow=old;previous?.focus();}},[]);
 return <dialog ref={ref} aria-label={label} className={`modal ${className}`} onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===e.currentTarget)onClose();}}><div className="modal-content"><button className="close icon-button" onClick={onClose} aria-label="Close dialog"><span aria-hidden="true">×</span></button>{children}</div></dialog>
}

export function RoutineLink({children="Start your routine",className=""}:{children?:ReactNode;className?:string}){return <a className={`button ${className}`} href="#weekly-meals">{children}<Arrow diagonal/></a>}
