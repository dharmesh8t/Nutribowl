export const WA_CATALOG_URL = 'https://wa.me/c/919342136892';
export const DELIVERY_DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'] as const;
export type Category = 'Salads' | 'Smoothies' | 'Wellness shots';
export interface Product { id:string; name:string; category:Category; price:number; description:string; ingredients:string[]; image:string; protein?:number; calories?:number; nonVeg?:boolean; size?:string }
const salad = (id:string,name:string,price:number,description:string,ingredients:string[],photo:string,protein:number,calories:number,nonVeg=false):Product => ({id,name,price,description,ingredients,image:`https://images.unsplash.com/${photo}?auto=format&fit=crop&w=720&q=80`,category:'Salads',protein,calories,nonVeg});
const shot = (id:string,name:string,ingredients:string[]):Product => ({id,name,ingredients,price:40,category:'Wellness shots',description:ingredients.join(', ')+'. A fresh addition to your morning ritual.',image:'/assets/shots.webp',size:'200 ml'});
const smoothie = (id:string,name:string,price:number,ingredients:string[]):Product => ({id,name,price,ingredients,category:'Smoothies',description:ingredients.join(', ')+'. Cold-blended for an easy morning.',image:'/assets/smoothie.webp',size:'500 ml'});
export const products:Product[] = [
 salad('paneer-power-salad','Paneer Power Salad',190,'Grilled paneer, chickpeas and a fresh mint yogurt dressing.',['Grilled paneer','Chickpeas','Mint yogurt dressing'],'photo-1540420773420-3366772f4999',24,380),
 smoothie('banana-date-smoothie','Classic Banana Date Smoothie',100,['Banana','Dates','Oats','Milk','Honey']),
 shot('ginger-glow-shot','Ginger Glow Shot',['Ginger','Lemon','Cayenne']),
 salad('grilled-chicken-salad','Grilled Chicken Salad',220,'Grilled chicken and mixed greens with an olive oil dressing.',['Grilled chicken','Mixed greens','Olive oil dressing'],'photo-1512621776951-a57141f2eefd',28,410,true),
 salad('protein-legume-salad','Protein Legume Salad',170,'A colourful mix of sprouts, chickpeas and kidney beans.',['Sprouts','Chickpeas','Kidney beans','Lemon dressing'],'photo-1505576399279-565b52d4ac71',20,340),
 salad('mediterranean-pasta-salad','Mediterranean Pasta Salad',200,'Whole-wheat pasta, olives and feta, finished with basil.',['Whole-wheat pasta','Olives','Feta','Basil'],'photo-1473093295043-cdd812d0e601',14,420),
 salad('seasonal-fruit-bowl','Seasonal Fruit Bowl',150,'Whatever is freshest this week, cut and chilled.',['Seasonal fresh fruit'],'photo-1490474418585-ba9bad8fd0ea',3,180),
 salad('quinoa-avocado-salad','Quinoa Avocado Salad',210,'Quinoa, creamy avocado and corn with a lime dressing.',['Quinoa','Avocado','Corn','Lime dressing'],'photo-1512621776951-a57141f2eefd',12,360),
 smoothie('almond-cashew-smoothie','Almond Cashew Power Smoothie',110,['Almonds','Cashews','Oats','Pumpkin seeds']),
 smoothie('avocado-honey-smoothie','Honey Avocado Glow Smoothie',110,['Avocado','Banana','Honey','Sunflower seeds']),
 shot('spinach-shot','Spinach Shot',['Spinach','Lemon','Ginger']),
 shot('beetroot-shot','Beetroot Shot',['Beetroot','Carrot','Ginger']),
 shot('turmeric-shot','Turmeric Shot',['Turmeric','Black pepper','Lemon']),
 shot('cucumber-aloe-shot','Cucumber Aloe Shot',['Cucumber','Aloe vera','Mint']),
 shot('carrot-orange-shot','Carrot Orange Shot',['Carrot','Orange','Turmeric'])
];
export const testimonials = [
 {name:'Aditi R.',location:'Auroville',quote:'My mornings changed completely. The shots are part of my routine now and delivery has never once been late.'},
 {name:'Karthik M.',location:'Puducherry',quote:'Been on the Paneer Power Salad weekly plan for two months. Consistent quality every single day.'},
 {name:'Fatima J.',location:'Auroville Bioregion',quote:'Finally a healthy option that does not feel like a chore to order. Subscribe once and forget about it.'},
 {name:'Sundar V.',location:'Puducherry',quote:'The smoothies keep me full till lunch. Worth the small delivery fee for how consistent it is.'}
];
export const faqs = [
 ['How does the new five-day meal plan work?','Choose breakfast, lunch, dinner or the full-day combo for 21–25 September 2026. Choose a 500 ml, 750 ml or 1,000 ml box per meal, select your days and request the plan on WhatsApp. Meals are ₹180 each; delivery times and charges are confirmed separately. Nutrition figures are illustrative recipe estimates.'],
 ['How does delivery work?','We deliver fresh every morning, Monday to Saturday, between 8:00 AM and 9:30 AM, straight to your door in Auroville, the Auroville Bioregion, or Puducherry.'],
 ['Can I subscribe to just one product?','Yes. Every product can be subscribed to weekly, monthly or on custom days. Choose only salads, smoothies or shots, or combine your favourites.'],
 ['Can I pause my subscription?','The existing Nutribowl service offers subscription pauses. Contact the team on WhatsApp to arrange a pause and confirm when deliveries will resume.'],
 ['Can I cancel anytime?','Nutribowl’s existing plans have no lock-in. Contact the team on WhatsApp to arrange cancellation and confirm the details for your plan.'],
 ['Can I skip tomorrow?','Contact Nutribowl before your delivery window to request a skipped day. Confirm the change with the team on WhatsApp before assuming your delivery has been stopped.'],
 ['Is delivery free everywhere?','Delivery is free in Auroville and the Auroville Bioregion. Puducherry delivery costs ₹30 per delivery.'],
 ['How do I confirm my routine?','Choose your products in the routine planner, then select Review & pay online for a weekly or custom routine when checkout is available. Confirm delivery availability and terms with Nutribowl first. Monthly plans are confirmed on WhatsApp. Website payments are one-time payments, not automatic renewals.']
];
export const money = (n:number) => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n);
