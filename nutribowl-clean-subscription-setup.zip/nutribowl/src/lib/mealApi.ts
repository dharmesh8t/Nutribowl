export async function mealApi(body?:unknown){const response=await fetch('/api/meal-orders',{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});const data=await response.json().catch(()=>({error:'Ordering is not connected yet.'}));if(!response.ok)throw new Error(data.error||'Unable to reach Nutribowl. Please try again.');return data;}
export type MealConfig={ordersEnabled:boolean;paymentsEnabled:boolean;emailAlerts:boolean;deliveryFeePerDay:number|null;testMode:boolean};
export type MealOrder={id:string;status:string;paymentState:string;testMode:boolean;paymentsEnabled:boolean;razorpayOrderId:string|null;paymentId:string|null;plan:{week:string;choice:string;diet:string;size:number;food:number;delivery:number|null;total:number|null;mealCount:number;menu:{day:string;date:string;meals:{slot:string;title:string}[]}[]}};
export const orderStatus=(status:string)=>({awaiting_payment:'Awaiting payment',paid:'Payment received',confirmed:'Subscription confirmed',refunded:'Refund recorded'}[status]||status);
export type OrderReference={id:string;token:string};
const key='nutribowl-meal-order';
export function savedOrder():OrderReference|null{try{const ref=JSON.parse(sessionStorage.getItem(key)||'null');return ref?.id&&ref?.token?ref:null;}catch{return null;}}
export function rememberOrder(ref:OrderReference){try{sessionStorage.setItem(key,JSON.stringify(ref));}catch{}}
export function newReference():OrderReference{return{id:crypto.randomUUID(),token:Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('')};}
