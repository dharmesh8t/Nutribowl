import { products } from '../data/catalog';
export type Frequency = 'Weekly'|'Monthly'|'Custom';
export function estimate(ids:string[], days:number[], area:string,frequency:Frequency) {
 const selected = products.filter(p=>ids.includes(p.id));
 const daily = selected.reduce((sum,p)=>sum+p.price,0);
 const delivery = area === 'Puducherry' ? 30 : 0;
 const count = frequency === 'Weekly' ? 6 : days.length;
 return {selected,daily,delivery,count,total:(daily+delivery)*count,valid:selected.length>0&&count>0};
}
