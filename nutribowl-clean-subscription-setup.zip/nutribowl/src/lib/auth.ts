export type AuthMode='signin'|'signup'|'reset';
export type AuthValues=Record<string,string>;
export interface AuthResult {ok:boolean;message:string}
export interface AuthService {signIn:(values:AuthValues)=>Promise<AuthResult>;signUp:(values:AuthValues)=>Promise<AuthResult>;resetPassword:(values:AuthValues)=>Promise<AuthResult>}
// Replace this adapter with the project's verified authentication service.
// The preview never sends, logs or persists credentials and never claims a session exists.
async function unavailable():Promise<AuthResult>{return {ok:false,message:'Account access is not connected yet. You can subscribe directly through our WhatsApp catalog without an account.'}}
export const authService:AuthService={signIn:unavailable,signUp:unavailable,resetPassword:unavailable};
export function strength(password:string){return Math.min(4,Number(password.length>=8)+Number(password.length>=12)+Number(/[A-Z]/.test(password)&&/[a-z]/.test(password))+Number(/\d/.test(password)&&/[^a-zA-Z0-9]/.test(password)))}
export function validateAuth(mode:AuthMode,values:AuthValues):Record<string,string>{
 const errors:Record<string,string>={};
 const email=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;const phone=/^(?:\+91)?[6-9]\d{9}$/;
 if(mode==='signup'){
  if(!values.name?.trim())errors.name='Enter your full name.';
  if(!email.test(values.email||''))errors.email='Enter a valid email address.';
  if(!phone.test((values.mobile||'').replace(/[\s()-]/g,'')))errors.mobile='Enter a 10-digit Indian mobile number, optionally with +91.';
  if((values.password||'').length<8)errors.password='Use at least 8 characters.';
  if(!values.confirm||values.confirm!==values.password)errors.confirm='Passwords must match.';
 }else{
  const value=(values.identity||'').trim();if(!email.test(value)&&!phone.test(value.replace(/[\s()-]/g,'')))errors.identity='Enter your email address or Indian mobile number.';
  if(mode==='signin'&&!values.password)errors.password='Enter your password.';
 }
 return errors;
}
