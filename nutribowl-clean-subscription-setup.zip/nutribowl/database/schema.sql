-- Run once in your Supabase SQL editor. Only server-side service_role has access.
create table if not exists public.meal_orders (
 id uuid primary key,
 token_hash text not null,
 created_at timestamptz not null default now(),
 customer jsonb not null,
 plan jsonb not null,
 status text not null default 'awaiting_payment' check (status in ('awaiting_payment','paid','confirmed','refunded')),
 payment_state text not null default 'new',
 razorpay_order_id text unique,
 payment_id text,
 is_test boolean not null default true,
 confirmed_at timestamptz,
 alert_error boolean not null default false
);
alter table public.meal_orders enable row level security;
revoke all on public.meal_orders from anon, authenticated;
grant select, insert, update on public.meal_orders to service_role;
create index if not exists meal_orders_created on public.meal_orders (created_at desc);
create index if not exists meal_orders_payment on public.meal_orders (payment_id);
