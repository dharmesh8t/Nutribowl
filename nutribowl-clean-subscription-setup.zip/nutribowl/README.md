# Nutribowl — five-day meal subscriptions

A responsive React/TypeScript site with a Monday–Friday breakfast/lunch/dinner table, meal-photo placeholders, vegetarian and egg/chicken options, three portion sizes and a two-step subscription form. Current week: 21–25 September 2026.

## Start here

- **OWNER-GUIDE.md**: where customer details go, owner Orders page, email alerts and one-time service setup.
- **IMAGE-GUIDE.md**: how to add your meal photos.
- **MEAL-PLAN-NOTES.md**: menu interpretations, prices and illustrative nutrition assumptions.
- **PAYMENT-SETUP.md**: connect and test Razorpay when the merchant account is ready.

No accounts are connected by this source package. Without settings, the customer flow is explicitly a preview and does not save details or accept payment. Email recipient is configured in `.env.example` as dharmesh8m@gmail.com; actual delivery requires a verified sender and Resend credentials.

## Local development

Use Node 22+:

```
npm ci
npm run build
npm test
npm run test:payments
npm run test:orders
npm start
```

Open http://127.0.0.1:5175. `PORT=5176 npm start` uses another local port. `npm run dev` runs only the frontend. To load private local test settings, copy `.env.example` to `.env`, fill values locally, then use `node --env-file=.env dev-server.mjs`. Never commit `.env`.

## Main files

- `src/sections/WeeklyMeals.tsx`: menu table and selectors.
- `src/data/mealPlan.ts`: dates, recipes, prices and assumed portion/nutrition profiles.
- `src/components/MealCheckout.tsx`: customer details → payment/status.
- `src/components/OwnerOrders.tsx`: private owner sign-in and Orders page at `/#owner`.
- `api/meal-orders.mjs`, `server/meal-orders.mjs`: order save, payment creation and reconciliation.
- `api/owner.mjs`, `server/owner-auth.mjs`: owner API and signed HttpOnly sessions.
- `server/alerts.mjs`: owner emails via Resend.
- `database/schema.sql`: private Supabase order table.
- `public/assets/meals`: your meal images.

Build generates both browser output and server menu modules. Deploy the entire source to Vercel (build `npm run build`, output `dist`, Node 22+). Existing legacy catalog/components are kept as source history but are not rendered on the public homepage; the former create-order endpoint returns 410. Old payment status remains available for recovery.

This update is prepared locally, not published to the live Vercel site. Unit checks cover menu/totals, customer validation, duplicate requests, signature tampering, captured/refunded payments and owner sessions. Provider-backed database, email and Razorpay tests require your accounts and remain outstanding.
