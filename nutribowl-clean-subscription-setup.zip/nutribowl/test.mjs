import ts from 'typescript';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve('.test-build');
// Compile only pure business logic and tests; node:test runs in this process.
for(const file of ['src/data/catalog.ts','src/lib/routine.ts','src/lib/auth.ts','tests/logic.test.ts','src/data/mealPlan.ts','tests/meals.test.ts']){const out=path.join(root,file.replace(/\.ts$/,'.js'));fs.mkdirSync(path.dirname(out),{recursive:true});let code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;code=code.replace(/(from ['"])(\.[^'"]+)(['"])/g,'$1$2.js$3');fs.writeFileSync(out,code)}
await import('./.test-build/tests/logic.test.js');

await import('./.test-build/tests/meals.test.js');
