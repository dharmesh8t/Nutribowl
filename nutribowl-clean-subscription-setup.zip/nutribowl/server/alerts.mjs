import {store} from './order-store.mjs';
export function emailReady(env=process.env){return !!env.RESEND_API_KEY&&!!env.OWNER_EMAIL&&!!env.ALERT_FROM_EMAIL&&!!env.PUBLIC_SITE_URL;}
export async function alertOwner(row,event,env=process.env){
 if(!emailReady(env))return false;
 try{
 const label={new:'New meal subscription request',paid:'Payment verified',confirmed:'Subscription confirmed',refunded:'Payment refunded'}[event];
 const amount=row.plan.total===null?'Delivery price pending':'INR '+(row.plan.total/100).toFixed(2);
 const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':`nutribowl-${row.id}-${event}`},body:JSON.stringify({from:env.ALERT_FROM_EMAIL,to:[env.OWNER_EMAIL],subject:`${row.is_test?'[TEST] ':''}${label} · Nutribowl ${row.id.slice(0,8)}`,text:`${label}\nOrder: ${row.id}\nAmount: ${amount}\nStatus: ${row.status}\n\nOpen your private Orders page to view the customer's details and plan:\n${new URL('/#owner',env.PUBLIC_SITE_URL)}\n\nOnly fulfil live, paid subscriptions you have confirmed. No customer address or phone is included in this email.`}),signal:AbortSignal.timeout(10000)});
 if(!r.ok)throw new Error('Email unavailable');return true;
 }catch{try{await store.update(row.id,{alert_error:true});}catch{}return false;}
}
