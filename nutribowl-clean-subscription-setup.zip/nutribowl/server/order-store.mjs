export function storageReady(env=process.env){return /^https:\/\/[^/]+$/.test(env.SUPABASE_URL||'')&&!!env.SUPABASE_SERVICE_ROLE_KEY;}
export async function db(query='',{method='GET',body,prefer='return=representation'}={},env=process.env){
 if(!storageReady(env))throw new Error('Order storage unavailable');
 const res=await fetch(env.SUPABASE_URL+'/rest/v1/meal_orders?'+query,{method,headers:{apikey:env.SUPABASE_SERVICE_ROLE_KEY,Authorization:'Bearer '+env.SUPABASE_SERVICE_ROLE_KEY,'Content-Type':'application/json',Prefer:prefer},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 if(!res.ok)throw new Error('Order storage unavailable');return res.status===204?[]:res.json();
}
export const store={
 get:async id=>(await db('id=eq.'+encodeURIComponent(id)+'&limit=1'))[0],
 insert:async row=>(await db('on_conflict=id',{method:'POST',body:row,prefer:'resolution=ignore-duplicates,return=representation'}))[0],
 update:async(id,patch,condition='')=>(await db('id=eq.'+encodeURIComponent(id)+condition,{method:'PATCH',body:patch}))[0],
 find:async(field,value)=>{if(!['razorpay_order_id','payment_id'].includes(field))throw new Error('Invalid field');return(await db(field+'=eq.'+encodeURIComponent(value)+'&limit=1'))[0];},
 list:async offset=>db('select=id,created_at,customer,plan,status,payment_state,razorpay_order_id,payment_id,is_test,confirmed_at,alert_error&order=created_at.desc&limit=50&offset='+offset)
};
