import {createHash,timingSafeEqual} from 'node:crypto';
import {WEEK_MENU,PLAN_WEEK,BOXES,chosenSlots,getRecipe,mealTotal} from './mealPlan.mjs';
import {InputError,customer,todayIndia,ready,razorpay,validSignature} from './payments.mjs';
import {store,storageReady} from './order-store.mjs';
import {alertOwner,emailReady} from './alerts.mjs';
export const hash=value=>createHash('sha256').update(value).digest('hex');
export const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(value);
export function authOrder(row,token){return !!row&&typeof token==='string'&&/^[a-f0-9]{64}$/.test(token)&&timingSafeEqual(Buffer.from(row.token_hash,'hex'),Buffer.from(hash(token),'hex'));}
export function fee(env=process.env){return /^\d{1,6}$/.test(env.MEAL_DELIVERY_FEE_PER_DAY_PAISE||'')?Number(env.MEAL_DELIVERY_FEE_PER_DAY_PAISE):null;}
export function config(env=process.env){return{ordersEnabled:env.ORDERS_ENABLED==='true'&&storageReady(env),paymentsEnabled:env.MEAL_SERVICE_READY==='true'&&ready(env)&&fee(env)!==null,emailAlerts:emailReady(env),deliveryFeePerDay:fee(env),testMode:!(env.RAZORPAY_KEY_ID||'').startsWith('rzp_live_'),week:PLAN_WEEK.label};}
export function validateRequest(input,env=process.env,now=new Date()){
 if(!uuid(input?.id)||typeof input?.token!=='string'||!/^[a-f0-9]{64}$/.test(input.token))throw new InputError('Please reopen the order form.');
 if(!['breakfast','lunch','dinner','combo'].includes(input.choice)||!['veg','mixed'].includes(input.diet)||![500,750,1000].includes(input.size))throw new InputError('Choose a valid meal plan.');
 if(todayIndia(now)>=PLAN_WEEK.start)throw new InputError('Bookings for this menu have closed. Please contact Nutribowl for the next menu.');
 const contact=customer({...input.customer,accepted:input.customer?.accepted});
 if(typeof input.customer.email!=='string'||input.customer.email.length>160||!/^\S+@[^\s@]+\.[^\s@]+$/.test(input.customer.email))throw new InputError('Enter a valid email address.');
 if(!['Auroville','Auroville Bioregion','Puducherry'].includes(input.customer.area))throw new InputError('Choose a supported delivery area.');
 const delivery=fee(env),food=mealTotal(input.choice,5)*100;
 const slots=chosenSlots(input.choice),box=BOXES.find(b=>b.size===input.size);
 return{id:input.id,token_hash:hash(input.token),customer:{...contact,email:input.customer.email.trim().toLowerCase(),area:input.customer.area},plan:{week:PLAN_WEEK.label,choice:input.choice,diet:input.diet,size:input.size,box:box.name,days:5,mealCount:slots.length*5,food,delivery:delivery===null?null:delivery*5,total:delivery===null?null:food+delivery*5,menu:WEEK_MENU.map(d=>({day:d.day,date:d.date,meals:slots.map(s=>({slot:s,title:getRecipe(d,s,input.diet).title}))}))},status:'awaiting_payment',payment_state:'new',is_test:config(env).testMode};
}
export function publicOrder(row,env=process.env){return{id:row.id,plan:row.plan,status:row.status,paymentState:row.payment_state,testMode:row.is_test,razorpayOrderId:row.razorpay_order_id||null,paymentId:row.payment_id||null,paymentsEnabled:config(env).paymentsEnabled};}
export async function submit(input,env=process.env,storage=store,now=new Date()){
 const existing=await storage.get(input?.id||'');
 if(existing){if(!authOrder(existing,input.token))throw new InputError('Order reference invalid.');return publicOrder(existing,env);}
 if(!config(env).ordersEnabled)throw new InputError('Orders are not connected yet. No details were saved.');
 const candidate=validateRequest(input,env,now),created=await storage.insert(candidate),row=created||await storage.get(candidate.id);
 if(!authOrder(row,input.token))throw new InputError('Order reference invalid.');
 if(created)await alertOwner(row,'new',env);
 return publicOrder(row,env);
}
export async function owned(input,storage=store){if(!uuid(input?.id))throw new InputError('Order reference invalid.');const row=await storage.get(input.id);if(!authOrder(row,input.token))throw new InputError('Order reference invalid.');return row;}
export async function startPayment(input,env=process.env,storage=store,api=razorpay,now=new Date()){
 const row=await owned(input,storage);
 if(!config(env).paymentsEnabled||row.plan.total===null)throw new InputError('Payment is not available yet. Nutribowl will contact you.');
 if(row.is_test!==config(env).testMode)throw new InputError('This order belongs to a different payment mode. Contact Nutribowl.');
 if(['paid','confirmed','refunded'].includes(row.status))throw new InputError('Check the existing payment status.');
 if(!row.plan.menu?.[0]?.date||todayIndia(now)>=row.plan.menu[0].date)throw new InputError('Payment for this menu has closed. Contact Nutribowl.');
 if(row.razorpay_order_id)return{keyId:env.RAZORPAY_KEY_ID,orderId:row.razorpay_order_id,amount:row.plan.total,testMode:row.is_test};
 const locked=await storage.update(row.id,{payment_state:'creating'},'&payment_state=eq.new&razorpay_order_id=is.null');
 if(!locked)throw new InputError('A payment order is already being prepared. Check status before trying again.');
 // Keep the lock on uncertain provider errors; never create a second chargeable order blindly.
 const provider=await api('orders',{amount:row.plan.total,currency:'INR',receipt:row.id,notes:{business:'Nutribowl',meal_order_id:row.id,week:row.plan.week,plan:row.plan.choice}},env);
 if(provider.amount!==row.plan.total||provider.currency!=='INR'||!/^order_[A-Za-z0-9]+$/.test(provider.id||''))throw new Error('Provider order mismatch');
 await storage.update(row.id,{razorpay_order_id:provider.id,payment_state:'ready'});
 return{keyId:env.RAZORPAY_KEY_ID,orderId:provider.id,amount:row.plan.total,testMode:row.is_test};
}
export async function reconcile(row,env=process.env,storage=store,api=razorpay){
 if(!row.razorpay_order_id)return row;
 if(row.is_test!==config(env).testMode)throw new InputError('Switch to the matching payment mode before checking this order.');
 const order=await api('orders/'+row.razorpay_order_id,undefined,env);
 if(order.notes?.meal_order_id!==row.id||order.amount!==row.plan.total||order.currency!=='INR')throw new Error('Payment order mismatch');
 const list=await api('orders/'+row.razorpay_order_id+'/payments',undefined,env);
 const matching=list.items?.filter(p=>p.order_id===order.id&&p.amount===row.plan.total&&p.currency==='INR')||[];
 const refund=matching.find(p=>p.amount_refunded>0),paid=matching.find(p=>p.status==='captured'&&!p.amount_refunded);
 if(refund){const updated=await storage.update(row.id,{status:'refunded',payment_state:'refunded',payment_id:refund.id});if(row.status!=='refunded')await alertOwner(updated,'refunded',env);return updated;}
 if(paid&&order.status==='paid'){
 // Conditional write preserves a concurrent owner confirmation and prevents duplicate transitions.
 const updated=await storage.update(row.id,{status:'paid',payment_state:'captured',payment_id:paid.id},'&status=eq.awaiting_payment');
 if(updated){await alertOwner(updated,'paid',env);return updated;}
 return await storage.get(row.id);
 }
 return row;
}
export async function check(input,env=process.env,storage=store,api=razorpay){let row=await owned(input,storage);if(input.paymentId&&(!row.razorpay_order_id||!validSignature(row.razorpay_order_id+'|'+input.paymentId,input.signature,env.RAZORPAY_KEY_SECRET)))throw new InputError('Payment signature invalid.');row=await reconcile(row,env,storage,api);return publicOrder(row,env);}
