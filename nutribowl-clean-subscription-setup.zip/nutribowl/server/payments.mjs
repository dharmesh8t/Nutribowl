import {createHmac, timingSafeEqual, randomUUID} from 'node:crypto';
import {products} from './catalog.mjs';
export class InputError extends Error {}
export const areas = ['Auroville', 'Auroville Bioregion', 'Puducherry'];
export function todayIndia(now = new Date()) { return new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(now); }
function text(value, min, max, label) { if(typeof value !== 'string' || value.trim().length < min || value.trim().length > max) throw new InputError(`Enter a valid ${label}.`); return value.trim(); }
export function quote(input, now = new Date()) {
 if(!input || !Array.isArray(input.ids) || input.ids.length < 1 || input.ids.length > products.length || new Set(input.ids).size !== input.ids.length) throw new InputError('Choose your products again.');
 const items = input.ids.map(id=>{ const p=products.find(p=>p.id===id); if(!p) throw new InputError('A selected product is unavailable.'); return {id:p.id,name:p.name,price:p.price}; });
 if(!['Weekly','Custom'].includes(input.frequency)) throw new InputError('Monthly plans must be confirmed with Nutribowl on WhatsApp.');
 if(!areas.includes(input.area)) throw new InputError('Choose a supported delivery area.');
 if(!Array.isArray(input.days) || !input.days.length || input.days.length>6 || input.days.some(d=>!Number.isInteger(d)||d<0||d>5) || new Set(input.days).size!==input.days.length) throw new InputError('Choose valid delivery days.');
 if(input.frequency==='Weekly' && input.days.length!==6) throw new InputError('Weekly plans include Monday through Saturday.');
 if(typeof input.startDate!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(input.startDate)) throw new InputError('Choose a start date.');
 const start=new Date(input.startDate+'T00:00:00Z');
 const today=new Date(todayIndia(now)+'T00:00:00Z');
 if(!Number.isFinite(+start) || start.toISOString().slice(0,10)!==input.startDate || +start<=+today || +start>+today+30*86400000) throw new InputError('Choose a start date from tomorrow through the next 30 days.');
 const dates=Array.from({length:7},(_,i)=>new Date(+start+i*86400000)).filter(d=>input.days.includes((d.getUTCDay()+6)%7)).map(d=>d.toISOString().slice(0,10));
 const delivery=input.area==='Puducherry'?30:0;
 return {items,dates,area:input.area,frequency:input.frequency,delivery,amount:(items.reduce((s,p)=>s+p.price,0)+delivery)*dates.length*100,currency:'INR'};
}
export function customer(input) {
 const name=text(input?.name,2,80,'name'), phone=text(input?.phone,10,16,'Indian mobile number').replace(/[\s+-]/g,'').replace(/^91(?=\d{10}$)/,'');
 if(!/^[6-9]\d{9}$/.test(phone)) throw new InputError('Enter a valid 10-digit Indian mobile number.');
 const address=text(input?.address,10,240,'delivery address');
 const pincode=text(input?.pincode,6,6,'PIN code');
 if(!/^[1-9]\d{5}$/.test(pincode)) throw new InputError('Enter a valid Indian PIN code.');
 if(input?.accepted!==true) throw new InputError('Confirm your delivery details and payment terms.');
 return {name,phone:'+91'+phone,address,pincode};
}
export function sign(value, secret) {return createHmac('sha256',secret).update(value).digest('hex');}
export function validSignature(value, signature, secret) {return typeof signature==='string' && /^[a-f0-9]{64}$/.test(signature) && timingSafeEqual(Buffer.from(sign(value,secret),'hex'),Buffer.from(signature,'hex'));}
export function ready(env=process.env) {return env.CHECKOUT_ENABLED==='true' && /^rzp_(test|live)_/.test(env.RAZORPAY_KEY_ID||'') && !!env.RAZORPAY_KEY_SECRET && !!env.RAZORPAY_WEBHOOK_SECRET && !!env.PUBLIC_SITE_URL;}
export async function razorpay(path, body, env=process.env) {
 const r=await fetch('https://api.razorpay.com/v1/'+path,{method:body?'POST':'GET',headers:{Authorization:'Basic '+Buffer.from(env.RAZORPAY_KEY_ID+':'+env.RAZORPAY_KEY_SECRET).toString('base64'),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 if(!r.ok) throw new Error('Payment provider unavailable');
 return r.json();
}
export async function create(input, env=process.env, api=razorpay) {
 const q=quote(input), c=customer(input.customer);
 const order=await api('orders',{amount:q.amount,currency:'INR',receipt:'nb_'+randomUUID().replaceAll('-',''),notes:{business:'Nutribowl',customer_name:c.name,customer_phone:c.phone,address:c.address,pincode:c.pincode,area:q.area,plan:q.frequency,dates:q.dates.join(', '),product_ids:q.items.map(p=>p.id).join(',').slice(0,250),product_ids_extra:q.items.map(p=>p.id).join(',').slice(250),unit_prices_in_product_order:q.items.map(p=>String(p.price)).join(','),delivery_fee_per_day:String(q.delivery),fulfilment:'One of each selected item on each listed date; one-time payment'}},env);
 if(order.amount!==q.amount || order.currency!=='INR' || !/^order_[A-Za-z0-9]+$/.test(order.id||'')) throw new Error('Invalid payment order');
 return {...q,orderId:order.id,keyId:env.RAZORPAY_KEY_ID,token:sign('status|'+order.id,env.RAZORPAY_KEY_SECRET),testMode:env.RAZORPAY_KEY_ID.startsWith('rzp_test_')};
}
export async function status(input, env=process.env, api=razorpay) {
 if(!/^order_[A-Za-z0-9]+$/.test(input?.orderId||'') || !validSignature('status|'+input.orderId,input.token,env.RAZORPAY_KEY_SECRET)) throw new InputError('Order reference is invalid.');
 if(input.paymentId && (!/^pay_[A-Za-z0-9]+$/.test(input.paymentId) || !validSignature(input.orderId+'|'+input.paymentId,input.signature,env.RAZORPAY_KEY_SECRET))) throw new InputError('Payment verification failed.');
 const order=await api('orders/'+input.orderId,undefined,env);
 if(order.notes?.business!=='Nutribowl' || order.currency!=='INR') throw new InputError('Order not found.');
 const payments=await api('orders/'+input.orderId+'/payments',undefined,env);
 const captured=payments.items?.find(p=>p.order_id===order.id && p.status==='captured' && p.currency==='INR' && p.amount===order.amount && !p.amount_refunded);
 const paid=order.status==='paid' && !!captured;
 return {paid,orderId:order.id,paymentId:paid?captured.id:undefined,amount:order.amount,currency:'INR',dates:order.notes.dates,area:order.notes.area,testMode:env.RAZORPAY_KEY_ID.startsWith('rzp_test_')};
}
export function reply(res,code,data) {res.statusCode=code;res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(data));}
export async function readBody(req) {if(req.body && typeof req.body==='object'){if(Buffer.byteLength(JSON.stringify(req.body))>12000)throw new InputError('Request too large.');return req.body;}let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>12000)throw new InputError('Request too large.');}try{return JSON.parse(body);}catch{throw new InputError('Invalid request.');}}
export function endpoint(action) {return async(req,res)=>{
 if(req.method!=='POST')return reply(res,405,{error:'Method not allowed'});
 if(!ready())return reply(res,503,{error:'Online payment is not available yet. Please contact Nutribowl on WhatsApp.'});
 if(req.headers.origin!==new URL(process.env.PUBLIC_SITE_URL).origin)return reply(res,403,{error:'Request not allowed'});
 try {reply(res,200,await action(await readBody(req)));} catch(e) {reply(res,e instanceof InputError?400:502,{error:e instanceof InputError?e.message:'Unable to reach the payment service. If you paid, check payment status before trying again.'});}
};}
